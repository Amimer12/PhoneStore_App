import 'package:flutter/material.dart';
import '../../models/category.dart';
import '../../models/product.dart';
import '../../models/product_type.dart';
import '../../services/supabase_service.dart';
import '../../theme/app_theme.dart';
import '../../theme/category_icons.dart';
import 'product_form.dart';
import 'catalog_screen.dart';
import '../../widgets/selector_chips.dart';
import '../../widgets/app_logo.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ProductsScreen extends StatefulWidget {
  const ProductsScreen({super.key});

  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  final _service = SupabaseService.instance;

  List<Category> _categories = [];
  List<ProductType> _type1Options = [];
  List<Product> _allProducts = [];

  int? _selectedCategoryId;
  int? _selectedType1Id;
  String _search = '';
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      _categories = await _service.getCategories();
      if (_selectedCategoryId != null) {
        _type1Options = await _service.getTypes(categoryId: _selectedCategoryId, topLevelOnly: true);
      }
      _allProducts = await _service.getProducts(
        categoryId: _selectedCategoryId,
        type1Id: _selectedType1Id,
      );
    } catch (e) {
      // Common cause: RLS requires an authenticated session and none exists yet,
      // or the Supabase URL/anon key in main.dart aren't set correctly.
      _error = e.toString();
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  /// Search matches the product's reference OR its type/marque/category
  /// names — done client-side since the catalog is small and this avoids a
  /// more complex joined-column search query against Postgrest.
  List<Product> get _filtered {
    if (_search.trim().isEmpty) return _allProducts;
    final q = _search.trim().toLowerCase();
    return _allProducts.where((p) => p.searchBlob.contains(q)).toList();
  }

  Future<void> _onCategoryChanged(int? id) async {
    setState(() {
      _selectedCategoryId = id;
      _selectedType1Id = null;
      _type1Options = [];
    });
    await _load();
  }

  Future<void> _onType1Changed(int? id) async {
    setState(() => _selectedType1Id = id);
    await _load();
  }

  Future<void> _openForm({Product? product}) async {
    final saved = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => ProductForm(product: product)),
    );
    if (saved == true) _load();
  }

  Future<void> _confirmDelete(Product p) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Supprimer ce produit ?'),
        content: Text(p.displayLabel),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Annuler')),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Supprimer', style: TextStyle(color: AppColors.danger)),
          ),
        ],
      ),
    );
    if (ok == true) {
      await _service.deleteProduct(p.id);
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final products = _filtered;
    return Scaffold(
      appBar: AppBar(
        leading: const Padding(padding: EdgeInsets.all(10), child: AppLogo(size: 26)),
        title: const Text('Produits'),
        actions: [
          IconButton(
            icon: const Icon(Icons.category_outlined),
            tooltip: 'Gérer catégories / types / marques',
            onPressed: () async {
              await Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const CatalogScreen()),
              );
              _load();
            },
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Se déconnecter',
            onPressed: () => Supabase.instance.client.auth.signOut(),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openForm(),
        icon: const Icon(Icons.add),
        label: const Text('Ajouter'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: TextField(
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search, color: AppColors.grey),
                hintText: 'Chercher par référence, type, marque...',
                isDense: true,
              ),
              onChanged: (v) => setState(() => _search = v),
            ),
          ),
          _buildFilters(),
          const Divider(height: 1),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator(color: AppColors.gold))
                : _error != null
                    ? Center(
                        child: Padding(
                          padding: const EdgeInsets.all(24),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.error_outline, color: AppColors.danger, size: 40),
                              const SizedBox(height: 12),
                              Text(_error!, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.grey)),
                              const SizedBox(height: 16),
                              ElevatedButton(onPressed: _load, child: const Text('Réessayer')),
                            ],
                          ),
                        ),
                      )
                    : products.isEmpty
                    ? const Center(child: Text('Aucun produit', style: TextStyle(color: AppColors.grey)))
                    : RefreshIndicator(
                        onRefresh: _load,
                        color: AppColors.gold,
                        child: ListView.separated(
                          padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
                          itemCount: products.length,
                          separatorBuilder: (_, __) => const SizedBox(height: 10),
                          itemBuilder: (_, i) => _ProductCard(
                            product: products[i],
                            onTap: () => _openForm(product: products[i]),
                            onDelete: () => _confirmDelete(products[i]),
                          ),
                        ),
                      ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilters() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CategoryIconPicker(
            categories: _categories,
            selectedId: _selectedCategoryId,
            onSelect: _onCategoryChanged,
            allowClear: true,
          ),
          if (_selectedCategoryId != null) ...[
            const SizedBox(height: 12),
            TypeChipSelector(
              label: 'Type',
              items: _type1Options,
              selectedId: _selectedType1Id,
              onSelect: _onType1Changed,
              allowClear: true,
            ),
          ],
        ],
      ),
    );
  }
}

/// Card layout: marque + niveau2 name large & bold on their own line,
/// niveau1 type + category smaller underneath, and the reference code in
/// tiny muted text at the very bottom — matches how a worker actually scans
/// for a product (brand/variant first, broad category second, code last to
/// confirm).
class _ProductCard extends StatelessWidget {
  final Product product;
  final VoidCallback onTap;
  final VoidCallback onDelete;

  const _ProductCard({required this.product, required this.onTap, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    final primaryParts = [product.marqueName, product.type2Name].where((e) => e != null && e.isNotEmpty).toList();
    final primaryLine = primaryParts.isNotEmpty ? primaryParts.join(' - ') : (product.name ?? product.type1Name ?? '');

    final secondaryParts = [product.type1Name, product.categoryName].where((e) => e != null && e.isNotEmpty).toList();
    final secondaryLine = secondaryParts.join(' - ');

    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              if (product.displayImageUrl != null) ...[
                ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: SizedBox(
                    width: 56,
                    height: 56,
                    child: Image.network(product.displayImageUrl!, fit: BoxFit.cover),
                  ),
                ),
                const SizedBox(width: 14),
              ],
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      primaryLine,
                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        Icon(iconForKey(product.categoryIconKey), size: 12, color: AppColors.grey),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            secondaryLine,
                            style: const TextStyle(color: AppColors.grey, fontSize: 12.5),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 3),
                    Text(
                      product.reference,
                      style: const TextStyle(color: AppColors.grey, fontSize: 10.5, letterSpacing: 0.3),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text('${product.prix} DA', style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.black)),
                  IconButton(
                    icon: const Icon(Icons.delete_outline, color: AppColors.danger, size: 20),
                    onPressed: onDelete,
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}