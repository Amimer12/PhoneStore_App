class ProductType {
  final int id;
  final int categoryId;
  final int? parentId;
  final String name;
  final String? imageUrl;
  final int level;

  ProductType({
    required this.id,
    required this.categoryId,
    this.parentId,
    required this.name,
    this.imageUrl,
    required this.level,
  });

  factory ProductType.fromMap(Map<String, dynamic> map) => ProductType(
        id: map['id'] as int,
        categoryId: map['category_id'] as int,
        parentId: map['parent_id'] as int?,
        name: map['name'] as String,
        imageUrl: map['image_url'] as String?,
        level: map['level'] as int? ?? 1,
      );

  Map<String, dynamic> toMap() => {
        'category_id': categoryId,
        'parent_id': parentId,
        'name': name,
        'image_url': imageUrl,
        'level': level,
      };
}
